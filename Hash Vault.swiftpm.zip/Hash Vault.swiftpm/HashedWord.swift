//
//  HashedWord.swift
//  Hash Vault
//
//  Created by Nizamet Özkan on 8.04.2022.
//

import Foundation

struct HashedWord: Identifiable, Codable {
    let id: UUID
    var word: String
    var hashType: HashType
    var wordInHash: String
    
    init(id: UUID = UUID(), word: String, hashType: HashType, wordInHash: String) {
        self.id = id
        self.word = word
        self.hashType = hashType
        self.wordInHash = wordInHash
    }
}

enum HashType: String ,Codable {
    case SHA256 = "SHA256", SHA384 = "SHA384", SHA512 = "SHA512"
}
