//
//  ListView.swift
//  Hash Vault
//
//  Created by Nizamet Özkan on 8.04.2022.
//

import SwiftUI

struct ListView: View {
    @Binding var hashedWords: [HashedWord]
    @State private var query: String = ""
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView {
            List {
                ForEach(hashedWords) { word in
                    HStack(alignment: .center) {
                        Spacer()
                        VStack(alignment: .center, spacing: 6) {
                            if word.word == "" {
                                Text("\"EMPTY\"")
                                    .font(.headline)
                                    .padding(.bottom, 12)
                            } else {
                                Text(word.word)
                                    .font(.headline)
                                    .padding(.bottom, 12)
                            }
                            
                            Text("\(word.hashType.rawValue)")
                                .accessibilityLabel("\(word.hashType.rawValue)")
                                .accessibilityAddTraits([.isStaticText])
                            
                            Text("\(word.wordInHash)")
                                .accessibilityAddTraits([.isStaticText])
                                .padding(.bottom, 16)
                                .contextMenu {
                                    Button(action: {
                                        UIPasteboard.general.string = word.wordInHash
                                    }) {
                                        Text("Copy hash to clipboard")
                                        Image(systemName: "doc.on.doc")
                                    }
                                }
                        }
                        Spacer()
                    }
                }
                .onDelete(perform: delete)
            }
            .navigationTitle("Saved data")
            .toolbar {
                ToolbarItemGroup(placement: .navigationBarLeading) {
                    
                    Text("Hold to copy hash")
                        .font(.system(size: 16, weight: .light, design: .rounded))
                        .accessibilityLabel("Hold to copy hash")
                        .accessibilityAddTraits([.isStaticText])
                }
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    
                    Button("Dismiss") {
                        dismiss()
                    }
                    .accessibilityLabel("Dismiss")
                    .accessibilityAddTraits([.isButton])
                }
                
            }
        }
    }
    
    private func delete(at offsets: IndexSet) {
        hashedWords.remove(atOffsets: offsets)
        HashedWordStore.save(hashedWords: hashedWords) { result in
            if case .failure(let error) = result {
                fatalError(error.localizedDescription)
            }
        }
    }
}
