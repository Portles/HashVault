//
//  HashingManager.swift
//  Hash Vault
//
//  Created by Nizamet Özkan on 10.04.2022.
//

import CryptoKit
import Foundation

final class HashingManager {
    static func EncryptSHA256(word: String) -> String {
        let data = Data(word.utf8)
        let digest = SHA256.hash(data: data)
        let hash = digest.compactMap{ String(format: "%02x", $0) }.joined()
        return hash
    }
    
    static func EncryptSHA384(word: String) -> String {
        let data = Data(word.utf8)
        let digest = SHA384.hash(data: data)
        let hash = digest.compactMap{ String(format: "%02x", $0) }.joined()
        return hash
    }
    
    static func EncryptSHA512(word: String) -> String {
        let data = Data(word.utf8)
        let digest = SHA512.hash(data: data)
        let hash = digest.compactMap{ String(format: "%02x", $0) }.joined()
        return hash
    }
}
