import SwiftUI

struct ContentView: View {
    @StateObject private var wordStore = HashedWordStore()
    
    var body: some View {
        HomeView(hashedWords: $wordStore.hashedWords)
            .onAppear {
                HashedWordStore.load { result in
                    switch result {
                    case .failure(let error):
                        fatalError(error.localizedDescription)
                    case .success(let hashedWords):
                        wordStore.hashedWords = hashedWords
                    }
                }
            }
    }
}

