//
//  File.swift
//  Hash Vault
//
//  Created by Nizamet Özkan on 7.04.2022.
//

import SwiftUI
import CryptoKit
import AVFoundation

struct HomeView: View {
    @Binding var hashedWords: [HashedWord]
    
    @State private var isDecryptMode: Bool = false
    
    @State private var screenSize = UIScreen.main.bounds.size
    
    //ENCRYPTION
    @State private var showList: Bool = false
    @State private var viewState = CGSize.zero
    @State private var selectedHashAlgorithm: HashType = .SHA256
    @State private var input: String = ""
    @State private var hashedValue: String = "Empty"
    @State private var wordHardness: Float = 0
    
    @State private var textState: CGSize = CGSize.zero
    
    @State private var onDrag: Bool = false
    @State private var shakeIt: Bool = false
    @State private var whellAnimation: Bool = false
    
    //DECRYPTION
    @State private var hashInput: String = ""
    @State private var decryptedWord: String = ""
    
    @FocusState private var isFocused: Bool
    
    private let player: AVQueuePlayer = AVQueuePlayer()
    private let feedbackGenerator = UINotificationFeedbackGenerator()
    
    var body: some View {
        ZStack {
            Image("Vault")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .foregroundColor(Color("Metalic"))
                .rotationEffect(Angle(degrees: whellAnimation ? 360 : 0.0))
                .onAppear {
                    withAnimation(Animation.linear(duration: 15).repeatForever(autoreverses: false)) {
                        whellAnimation = true
                    }
                }
                .onDisappear {
                    whellAnimation = false
                }
                .accessibilityLabel("Spinning vault door")
                .accessibilityAddTraits([.isImage])
            
            VStack(spacing: 12) {
                HStack(alignment: .top) {
                    if self.isDecryptMode {
                        Text("Decrypt")
                            .font(.system(.largeTitle, design: .rounded))
                            .fontWeight(.bold)
                            .accessibilityLabel("Decrypt")
                            .accessibilityAddTraits([.isHeader])
                    } else {
                        Text("Encrypt")
                            .font(.system(.largeTitle, design: .rounded))
                            .fontWeight(.bold)
                            .accessibilityLabel("Encrypt")
                            .accessibilityAddTraits([.isHeader])
                    }
                    
                    Spacer()
                    
                    Button (action:{
                        withAnimation(Animation.default) {
                            self.isDecryptMode.toggle()
                        }
                    })  {
                        Image(systemName: "arrow.triangle.2.circlepath.circle")
                            .foregroundColor(.primary)
                            .font(.system(size: 16, weight: .medium))
                            .frame(width: 45, height: 45)
                            .background(.ultraThinMaterial)
                            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                            .shadow(color: Color.black.opacity(0.1), radius: 1, x: 0, y: 1)
                            .shadow(color: Color.black.opacity(0.2), radius: 10, x: 0, y: 10)
                    }
                    .accessibilityAddTraits([.isButton])
                    .accessibilityLabel("Mode Switch")
                    
                    Button (action:{
                        self.showList.toggle()
                    })  {
                        Image(systemName: "list.bullet.rectangle.portrait")
                            .foregroundColor(.primary)
                            .font(.system(size: 16, weight: .medium))
                            .frame(width: 45, height: 45)
                            .background(.ultraThinMaterial)
                            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                            .shadow(color: Color.black.opacity(0.1), radius: 1, x: 0, y: 1)
                            .shadow(color: Color.black.opacity(0.2), radius: 10, x: 0, y: 10)
                            .offset(y: shakeIt ? 10 : 0)
                    }
                    .sheet(isPresented: $showList) {
                        ListView(hashedWords: self.$hashedWords)
                    }
                    .accessibilityAddTraits([.isButton])
                    .accessibilityLabel("Open List")
                    
                }
                .padding(.horizontal)
                .padding(.leading, 14)
                .padding(.top, 60)
                
                if isDecryptMode {
                    VStack(spacing: 24) {
                        Text("Paste your hash here")
                            .font(.system(size: 18, weight: .light, design: .rounded))
                            .accessibilityLabel("Paste your hash here")
                            .accessibilityAddTraits([.isStaticText])
                        
                        TextEditor(text: $hashInput)
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .textInputAutocapitalization(.never)
                            .multilineTextAlignment(.center)
                            .frame(maxWidth: 300, maxHeight: 135)
                            .onChange(of: hashInput){ newValue in
                                FindWord(hash: newValue)
                            }
                            .focused($isFocused)
                            .cornerRadius(24)
                            .accessibilityLabel("Hash text field")
                            .disabled(true)
                        
                        HStack(spacing: 120) {
                            Button(action: {
                                hashInput = ""
                                decryptedWord = ""
                            }) {
                                HStack {
                                    Text("Clear")
                                        .foregroundColor(.primary)
                                        .font(.system(size: 18))
                                }
                            }
                            .background{
                                RoundedRectangle(cornerRadius: 12, style: .continuous)
                                    .fill(.ultraThinMaterial)
                                    .shadow(color: Color.black.opacity(0.1), radius: 1, x: 0, y: 1)
                                    .shadow(color: Color.black.opacity(0.2), radius: 10, x: 0, y: 10)
                                    .frame(minWidth: 120, idealWidth: 130, maxWidth: 140, minHeight: 45, idealHeight: 45, maxHeight: 50, alignment: .center)
                            }
                            .accessibilityLabel("Clear")
                            .accessibilityAddTraits([.isButton])
                            
                            Button(action: {
                                hashInput = UIPasteboard.general.string ?? "First copy a hash"
                            }) {
                                HStack {
                                    Text("Paste")
                                        .foregroundColor(.primary)
                                        .font(.system(size: 18))
                                }
                            }.background{
                                RoundedRectangle(cornerRadius: 12, style: .continuous)
                                    .fill(.ultraThinMaterial)
                                    .shadow(color: Color.black.opacity(0.1), radius: 1, x: 0, y: 1)
                                    .shadow(color: Color.black.opacity(0.2), radius: 10, x: 0, y: 10)
                                    .frame(minWidth: 120, idealWidth: 130, maxWidth: 140, minHeight: 45, idealHeight: 45, maxHeight: 50, alignment: .center)
                            }
                            .accessibilityLabel("Paste")
                            .accessibilityAddTraits([.isButton])
                        }
                    }
                    
                    Spacer()
                    
                    Text("Your hash need to be stored on list!")
                        .font(.system(size: 16, weight: .light, design: .rounded))
                        .padding(.bottom, 12)
                        .accessibilityLabel("Your hash need to be stored on list!")
                        .accessibilityAddTraits([.isStaticText])
                    
                    DecryptedDataView(decryptedValue: $decryptedWord)
                        .frame(maxWidth: 300, minHeight: 140)
                        .background(.ultraThinMaterial)
                        .cornerRadius(24)
                        .padding(.bottom, 24)
                        .contextMenu {
                            Button(action: {
                                UIPasteboard.general.string = decryptedWord
                            }) {
                                Text("Copy word to clipboard")
                                Image(systemName: "doc.on.doc")
                            }
                            .accessibilityLabel("Copy Button")
                            .accessibilityAddTraits([.isButton])
                        }
                        .accessibilityLabel("Decrypted Data View")
                        .accessibilityAddTraits([.isModal, .isStaticText])
                        .accessibilityHint("Long Press to see copy button")
                    
                } else {
                    VStack(spacing: 12) {
                        HStack {
                            Spacer()
                            
                            Menu {
                                Button(action: {
                                    selectedHashAlgorithm = .SHA256
                                    CalcutateHash(input: input)
                                }) {
                                    Label("SHA256", systemImage: "plus.circle")
                                }
                                .accessibilityLabel("SHA256 algorithm")
                                .accessibilityAddTraits([.isButton])
                                
                                Button(action: {
                                    selectedHashAlgorithm = .SHA384
                                    CalcutateHash(input: input)
                                }) {
                                    Label("SHA384", systemImage: "plus.circle")
                                }
                                .accessibilityLabel("SHA384 algorithm")
                                .accessibilityAddTraits([.isButton])
                                
                                Button(action: {
                                    selectedHashAlgorithm = .SHA512
                                    CalcutateHash(input: input)
                                }) {
                                    Label("SHA512", systemImage: "plus.circle")
                                }
                                .accessibilityLabel("SHA512 algorithm")
                                .accessibilityAddTraits([.isButton])
                            } label: {
                                HStack {
                                    Text("Algorithm: \(selectedHashAlgorithm.rawValue)")
                                        .foregroundColor(.primary)
                                        .font(.system(size: 18))
                                }
                            }
                            .accessibilityLabel("Select hash algorithm")
                            .accessibilityAddTraits([.isButton])
                            .accessibilityHint("Currently \(selectedHashAlgorithm.rawValue) algorithm selected")
                            .background{
                                RoundedRectangle(cornerRadius: 12, style: .continuous)
                                    .fill(.ultraThinMaterial)
                                    .shadow(color: Color.black.opacity(0.1), radius: 1, x: 0, y: 1)
                                    .shadow(color: Color.black.opacity(0.2), radius: 10, x: 0, y: 10)
                                    .frame(minWidth: 190, idealWidth: 210, maxWidth: 220, minHeight: 55, idealHeight: 55, maxHeight: 60, alignment: .center)
                            }
                            .frame(minWidth: 200, idealWidth: 210, maxWidth: 220, minHeight: 55, idealHeight: 55, maxHeight: 60, alignment: .center)
                            
                            Spacer(minLength: 55)
                            
                            StrengthView(percent: $wordHardness, show: .constant(true))
                                .accessibilityLabel("Word strengths")
                                .accessibilityAddTraits([.isModal])
                            
                            Spacer(minLength: 25)
                        }
                        
                        TextField("", text: $input)
                            .placeholder(when: input.isEmpty) {
                                    Text("Type here").foregroundColor(.primary)
                            }
                            .font(.system(size: 24, weight: .bold, design: .rounded))
                            .textInputAutocapitalization(.never)
                            .textFieldStyle(.plain)
                            .multilineTextAlignment(.center)
                            .frame(maxWidth: 340, maxHeight: 35)
                            .onChange(of: input){ newValue in
                                CalcutateHash(input: newValue)
                            }
                            .focused($isFocused)
                            .accessibilityLabel("Type here")
                    }
                    
                    Spacer()
                    
                    Text("Swipe card to clear/save")
                        .font(.system(size: 16, weight: .light, design: .rounded))
                        .accessibilityLabel("Swipe to clear/save")
                        .accessibilityAddTraits([.isStaticText])
                    
                    HStack {
                        Image(systemName: "clear")
                        
                        HashDataView(hashedValue: $hashedValue)
                            .frame(maxWidth: 300, minHeight: 140)
                            .background(.ultraThinMaterial)
                            .cornerRadius(24)
                            .offset(x: textState.width)
                            .gesture(
                                DragGesture()
                                    .onChanged { value in
                                        self.textState = value.translation
                                        withAnimation(Animation.spring(response: 0.3, dampingFraction: 0.7, blendDuration: 0)){
                                            onDrag = true
                                        }
                                    }
                                    .onEnded { _ in
                                        debugPrint(textState.width)
                                        if self.textState.width > 50 {
                                            PlaySuccesNotification()
                                            SaveToList()
                                            withAnimation(Animation.default.repeatCount(3, autoreverses: true)) {
                                                shakeIt = true
                                            }
                                        } else if self.textState.width < -50 {
                                            PlayClearSound()
                                            ClearAll()
                                        }
                                        
                                        withAnimation(Animation.spring(response: 0.3, dampingFraction: 0.6, blendDuration: 0)){
                                            self.textState = .zero
                                            onDrag = false
                                        }
                                        shakeIt = false
                                    }
                            )
                            .accessibilityLabel("Hash data view")
                            .accessibilityAddTraits([.isModal])
                            .accessibilityHint("Swipe left to clear and swipe right to save your hash. Hold for copy hash")
                            .padding(.bottom, 24)
                            .contextMenu {
                                Button(action: {
                                    UIPasteboard.general.string = hashedValue
                                }) {
                                    Text("Copy hash to clipboard")
                                    Image(systemName: "doc.on.doc")
                                }
                                .accessibilityLabel("Copy")
                                .accessibilityAddTraits([.isButton])
                            }
                        
                        Image(systemName: "folder.badge.plus")
                    }
                    .padding(.bottom, 12)
                }
            }
        }
        .background(Color("Brass"))
        .onTapGesture {
            hideKeyboard()
        }
    }
    
    private func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
    
    private func CalculateWordHardness(input: String) -> Float {
        var point: Float = 0
        
        point = Float(input.count/2)
        
        for character in input{
            if character.isNumber{
                point *= 1.2
            } else
            if character.isLowercase{
                point *= 1.2
            } else
            if character.isUppercase{
                point *= 1.2
            } else
            if character.isASCII{
                point *= 1.6
            }
        }
        
        if point > 100 {
            point = 100
        }
        
        return point
    }
    
    private func HashToSelectedAlgo(word: String) {
        guard !word.isEmpty else {
            hashedValue = "Empty"
            return
        }
        
        switch selectedHashAlgorithm {
        case .SHA256:
            self.hashedValue = HashingManager.EncryptSHA256(word: word)
        case .SHA384:
            self.hashedValue = HashingManager.EncryptSHA384(word: word)
        case .SHA512:
            self.hashedValue = HashingManager.EncryptSHA512(word: word)
        }
    }
    
    private func SaveToList() {
        let data = HashedWord(word: input, hashType: selectedHashAlgorithm, wordInHash: hashedValue)
        hashedWords.append(data)
        HashedWordStore.save(hashedWords: hashedWords) { result in
            if case .failure(let error) = result {
                fatalError(error.localizedDescription)
            } else {
                input = ""
                HashToSelectedAlgo(word: input)
            }
        }
    }
    
    private func ClearAll() {
        input = ""
        hashedValue = "Empty"
        wordHardness = 0.0
    }
    
    private func CalcutateHash(input: String) {
        HashToSelectedAlgo(word: input)
        wordHardness = CalculateWordHardness(input: input)
        if input.isEmpty {isFocused = false}
        withAnimation(Animation.easeInOut(duration: 1).repeatForever(autoreverses: true)) {
            onDrag = false
        }
    }
    
    private func FindWord(hash: String) {
        for word in hashedWords {
            if word.wordInHash == hash {
                decryptedWord = word.word
                PlaySuccesNotification()
            }
        }
    }
    
    private func PlaySuccesNotification() {
        feedbackGenerator.notificationOccurred(.success)
    }
    
    private func PlayClearSound() {
        if let url = Bundle.main.url(forResource: "Pop", withExtension: "m4a") {
            player.removeAllItems()
            player.insert(AVPlayerItem(url: url), after: nil)
            player.play()
        }
    }
}

let screen = UIScreen.main.bounds

struct HashDataView: View {
    @Binding var hashedValue: String
    
    var body: some View {
        VStack {
            Text("Your Hash")
                .font(.system(.title3, design: .rounded))
                .fontWeight(.heavy)
                .padding(.horizontal, 12)
            
            Text("\(hashedValue)")
                .multilineTextAlignment(.center)
                .lineLimit(5)
                .padding(.bottom, 12)
                .padding(.horizontal, 12)
                .font(.system(size: 16))
        }
        
    }
}

struct DecryptedDataView: View {
    @Binding var decryptedValue: String
    
    var body: some View {
        VStack {
            Text("Your Decrypted Word")
                .font(.system(.title3, design: .rounded))
                .fontWeight(.heavy)
                .padding(.horizontal, 12)
                .padding(.bottom, 12)
            
            Text("\(decryptedValue)")
                .multilineTextAlignment(.center)
                .lineLimit(5)
                .padding(.bottom, 12)
                .padding(.horizontal, 12)
                .font(.system(size: 16))
            
        }
    }
}
extension View {
    func placeholder<Content: View>(
        when shouldShow: Bool,
        alignment: Alignment = .center,
        @ViewBuilder placeholder: () -> Content) -> some View {

        ZStack(alignment: alignment) {
            placeholder().opacity(shouldShow ? 1 : 0)
            self
        }
    }
}
